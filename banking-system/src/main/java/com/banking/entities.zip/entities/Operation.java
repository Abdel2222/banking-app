package com.banking.entities;

import com.banking.entity.enums.TypeOperation;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "operations")
public class Operation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "La date d'opération est obligatoire")
    @Column(name = "date_operation", nullable = false)
    private LocalDateTime dateOperation;

    @NotNull(message = "Le montant est obligatoire")
    @DecimalMin(value = "0.0", message = "Le montant doit être positif")
    @Column(name = "montant", nullable = false, precision = 15, scale = 2)
    private BigDecimal montant;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private TypeOperation type;

    @Column(name = "commentaire", length = 500)
    private String commentaire;

    @Column(name = "numero_compte_destinataire", length = 20)
    private String numeroCompteDestinataire;

    @Column(name = "nom_titulaire_destinataire", length = 100)
    private String nomTitulaireDestinataire;

    @Column(name = "communication", length = 200)
    private String communication;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // Relations
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "compte_bancaire_id", nullable = false)
    private CompteBancaire compteBancaire;

    @OneToOne(mappedBy = "operation", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Chat chat;

    // Constructeurs
    public Operation() {}

    public Operation(CompteBancaire compteBancaire, BigDecimal montant, TypeOperation type) {
        this.compteBancaire = compteBancaire;
        this.montant = montant;
        this.type = type;
        this.dateOperation = LocalDateTime.now();
    }

    public Operation(CompteBancaire compteBancaire, BigDecimal montant, TypeOperation type, String commentaire) {
        this(compteBancaire, montant, type);
        this.commentaire = commentaire;
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (dateOperation == null) {
            dateOperation = LocalDateTime.now();
        }

        // Validation selon le type d'opération
        if (type == TypeOperation.VIREMENT) {
            if (numeroCompteDestinataire == null || numeroCompteDestinataire.trim().isEmpty()) {
                throw new IllegalStateException("Le numéro de compte destinataire est requis pour un virement");
            }
        }
        if (type == TypeOperation.BLOCAGE_CARTE) {
            if (commentaire == null || commentaire.trim().isEmpty()) {
                throw new IllegalStateException("Un commentaire est requis pour un blocage de carte");
            }
        }
    }

    // Méthodes métier
    public boolean estVirement() {
        return TypeOperation.VIREMENT.equals(this.type);
    }

    public boolean estDepot() {
        return TypeOperation.DEPOT.equals(this.type);
    }

    public boolean estRetrait() {
        return TypeOperation.RETRAIT.equals(this.type);
    }

    public boolean estBlocageCarte() {
        return TypeOperation.BLOCAGE_CARTE.equals(this.type);
    }

    public boolean necessiteValidation() {
        return estVirement() || estBlocageCarte();
    }

    public String getDescriptionOperation() {
        switch (type) {
            case DEPOT:
                return "Dépôt de " + montant + "€";
            case RETRAIT:
                return "Retrait de " + montant + "€";
            case VIREMENT:
                return "Virement de " + montant + "€ vers " + numeroCompteDestinataire;
            case BLOCAGE_CARTE:
                return "Blocage de carte - " + commentaire;
            default:
                return "Opération " + type + " - " + montant + "€";
        }
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getDateOperation() {
        return dateOperation;
    }

    public void setDateOperation(LocalDateTime dateOperation) {
        this.dateOperation = dateOperation;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    public TypeOperation getType() {
        return type;
    }

    public void setType(TypeOperation type) {
        this.type = type;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public String getNumeroCompteDestinataire() {
        return numeroCompteDestinataire;
    }

    public void setNumeroCompteDestinataire(String numeroCompteDestinataire) {
        this.numeroCompteDestinataire = numeroCompteDestinataire;
    }

    public String getNomTitulaireDestinataire() {
        return nomTitulaireDestinataire;
    }

    public void setNomTitulaireDestinataire(String nomTitulaireDestinataire) {
        this.nomTitulaireDestinataire = nomTitulaireDestinataire;
    }

    public String getCommunication() {
        return communication;
    }

    public void setCommunication(String communication) {
        this.communication = communication;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public CompteBancaire getCompteBancaire() {
        return compteBancaire;
    }

    public void setCompteBancaire(CompteBancaire compteBancaire) {
        this.compteBancaire = compteBancaire;
    }

    public Chat getChat() {
        return chat;
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }
}