package com.banking.entities;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "clients")
@DiscriminatorValue("CLIENT")
public class Client extends Personne {  // Changé Person en Personne

    // Relation avec CompteBancaire
    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<CompteBancaire> comptes = new ArrayList<>();

    // Relation avec FraisDeGestion
    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<FraisDeGestion> fraisDeGestion = new ArrayList<>();

    // Constructeurs
    public Client() {
        super();
    }

    public Client(String prenom, String nom, String email, String motDePasse) {
        super(prenom, nom, email, motDePasse, "CLIENT");
    }

    // Getters et Setters pour CompteBancaire
    public List<CompteBancaire> getComptes() {
        return comptes;
    }

    public void setComptes(List<CompteBancaire> comptes) {
        this.comptes = comptes;
    }

    // Getters et Setters pour FraisDeGestion
    public List<FraisDeGestion> getFraisDeGestion() {
        return fraisDeGestion;
    }

    public void setFraisDeGestion(List<FraisDeGestion> fraisDeGestion) {
        this.fraisDeGestion = fraisDeGestion;
    }

    // Méthodes métier pour CompteBancaire
    public void ajouterCompte(CompteBancaire compte) {
        comptes.add(compte);
        compte.setClient(this);
    }

    public void supprimerCompte(CompteBancaire compte) {
        comptes.remove(compte);
        compte.setClient(null);
    }

    public int getNombreComptes() {
        return comptes.size();
    }

    public CompteBancaire getCompteParNumero(String numeroCompte) {
        return comptes.stream()
                .filter(compte -> compte.getNumCompte().equals(numeroCompte))
                .findFirst()
                .orElse(null);
    }

    public boolean aDesComptes() {
        return !comptes.isEmpty();
    }

    public List<CompteBancaire> getComptesActifs() {
        return comptes.stream()
                .filter(CompteBancaire::estActif)
                .toList();
    }

    public BigDecimal getSoldeTotal() {
        return comptes.stream()
                .map(CompteBancaire::getBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // Méthodes métier pour FraisDeGestion
    public void ajouterFrais(FraisDeGestion frais) {
        fraisDeGestion.add(frais);
        frais.setClient(this);
    }

    public void supprimerFrais(FraisDeGestion frais) {
        fraisDeGestion.remove(frais);
        frais.setClient(null);
    }

    public BigDecimal getTotalFraisActifs() {
        return fraisDeGestion.stream()
                .filter(FraisDeGestion::estEnCours)
                .map(FraisDeGestion::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public BigDecimal getTotalFraisFactures() {
        return fraisDeGestion.stream()
                .map(FraisDeGestion::getMontantTotalFacture)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public List<FraisDeGestion> getFraisEnCours() {
        return fraisDeGestion.stream()
                .filter(FraisDeGestion::estEnCours)
                .toList();
    }

    public List<FraisDeGestion> getFraisEchus() {
        return fraisDeGestion.stream()
                .filter(FraisDeGestion::estEchu)
                .toList();
    }

    public boolean aDesFraisImpayés() {
        return fraisDeGestion.stream()
                .anyMatch(frais -> frais.doitEtreFacture() && frais.getEstActif());
    }

    @Override
    public String toString() {
        return "Client{" +
                "id=" + getId() +
                ", nom='" + getNomComplet() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", nombreComptes=" + getNombreComptes() +
                ", totalFraisActifs=" + getTotalFraisActifs() +
                '}';
    }
}