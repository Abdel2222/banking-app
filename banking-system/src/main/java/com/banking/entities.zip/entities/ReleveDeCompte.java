package com.banking.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "releves_de_compte")
public class ReleveDeCompte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "La date de création est obligatoire")
    @Column(name = "date_releve", nullable = false)
    private LocalDate dateReleve;

    @NotNull(message = "Le solde initial est obligatoire")
    @DecimalMin(value = "0.0", message = "Le solde initial ne peut pas être négatif")
    @Column(name = "solde_initial", nullable = false, precision = 15, scale = 2)
    private BigDecimal soldeInitial;

    @NotNull(message = "Le solde final est obligatoire")
    @DecimalMin(value = "0.0", message = "Le solde final ne peut pas être négatif")
    @Column(name = "solde_final", nullable = false, precision = 15, scale = 2)
    private BigDecimal soldeFinal;

    @Column(name = "total_credits", precision = 15, scale = 2)
    private BigDecimal totalCredits = BigDecimal.ZERO;

    @Column(name = "total_debits", precision = 15, scale = 2)
    private BigDecimal totalDebits = BigDecimal.ZERO;

    @Column(name = "nombre_operations")
    private Integer nombreOperations = 0;

    @Column(name = "mois")
    private Integer mois;

    @Column(name = "annee")
    private Integer annee;

    @Column(name = "pdf_genere", nullable = false)
    private Boolean pdfGenere = false;

    @Column(name = "chemin_pdf")
    private String cheminPdf;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // Relations
    @ManyToMany(mappedBy = "releves")
    private List<CompteBancaire> comptes = new ArrayList<>();

    // Constructeurs
    public ReleveDeCompte() {
        this.createdAt = LocalDateTime.now();
        this.dateReleve = LocalDate.now();
        this.mois = LocalDate.now().getMonthValue();
        this.annee = LocalDate.now().getYear();
    }

    public ReleveDeCompte(BigDecimal soldeInitial, BigDecimal soldeFinal) {
        this();
        this.soldeInitial = soldeInitial;
        this.soldeFinal = soldeFinal;
        calculerTotaux();
    }

    public ReleveDeCompte(LocalDate dateReleve, BigDecimal soldeInitial, BigDecimal soldeFinal) {
        this();
        this.dateReleve = dateReleve;
        this.mois = dateReleve.getMonthValue();
        this.annee = dateReleve.getYear();
        this.soldeInitial = soldeInitial;
        this.soldeFinal = soldeFinal;
        calculerTotaux();
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (dateReleve == null) {
            dateReleve = LocalDate.now();
        }
        if (mois == null) {
            mois = dateReleve.getMonthValue();
        }
        if (annee == null) {
            annee = dateReleve.getYear();
        }
    }

    // Méthodes métier
    private void calculerTotaux() {
        BigDecimal difference = soldeFinal.subtract(soldeInitial);
        if (difference.compareTo(BigDecimal.ZERO) > 0) {
            this.totalCredits = difference;
            this.totalDebits = BigDecimal.ZERO;
        } else {
            this.totalCredits = BigDecimal.ZERO;
            this.totalDebits = difference.abs();
        }
    }

    public boolean estDuMoisCourant() {
        LocalDate now = LocalDate.now();
        return mois == now.getMonthValue() && annee == now.getYear();
    }

    public boolean estDeLAnneCourante() {
        return annee == LocalDate.now().getYear();
    }

    public String getPeriode() {
        String[] moisNoms = {"", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
                "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"};
        return moisNoms[mois] + " " + annee;
    }

    public BigDecimal getVariation() {
        return soldeFinal.subtract(soldeInitial);
    }

    public double getPourcentageVariation() {
        if (soldeInitial.compareTo(BigDecimal.ZERO) == 0) {
            return 0.0;
        }
        BigDecimal variation = getVariation();
        return variation.divide(soldeInitial, 4, BigDecimal.ROUND_HALF_UP)
                .multiply(new BigDecimal("100"))
                .doubleValue();
    }

    public void genererPdf(String cheminFichier) {
        this.pdfGenere = true;
        this.cheminPdf = cheminFichier;
    }

    public void addCompte(CompteBancaire compte) {
        if (!comptes.contains(compte)) {
            comptes.add(compte);
            compte.getReleves().add(this);
        }
    }

    public void removeCompte(CompteBancaire compte) {
        comptes.remove(compte);
        compte.getReleves().remove(this);
    }

    public void ajouterOperation(BigDecimal montant, boolean estCredit) {
        this.nombreOperations++;
        if (estCredit) {
            this.totalCredits = this.totalCredits.add(montant);
            this.soldeFinal = this.soldeFinal.add(montant);
        } else {
            this.totalDebits = this.totalDebits.add(montant);
            this.soldeFinal = this.soldeFinal.subtract(montant);
        }
    }

    // equals, hashCode et toString
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ReleveDeCompte)) return false;
        ReleveDeCompte that = (ReleveDeCompte) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "ReleveDeCompte{" +
                "id=" + id +
                ", periode='" + getPeriode() + '\'' +
                ", soldeInitial=" + soldeInitial +
                ", soldeFinal=" + soldeFinal +
                ", variation=" + getVariation() +
                ", nombreOperations=" + nombreOperations +
                '}';
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDateReleve() {
        return dateReleve;
    }

    public void setDateReleve(LocalDate dateReleve) {
        this.dateReleve = dateReleve;
    }

    public BigDecimal getSoldeInitial() {
        return soldeInitial;
    }

    public void setSoldeInitial(BigDecimal soldeInitial) {
        this.soldeInitial = soldeInitial;
    }

    public BigDecimal getSoldeFinal() {
        return soldeFinal;
    }

    public void setSoldeFinal(BigDecimal soldeFinal) {
        this.soldeFinal = soldeFinal;
    }

    public BigDecimal getTotalCredits() {
        return totalCredits;
    }

    public void setTotalCredits(BigDecimal totalCredits) {
        this.totalCredits = totalCredits;
    }

    public BigDecimal getTotalDebits() {
        return totalDebits;
    }

    public void setTotalDebits(BigDecimal totalDebits) {
        this.totalDebits = totalDebits;
    }

    public Integer getNombreOperations() {
        return nombreOperations;
    }

    public void setNombreOperations(Integer nombreOperations) {
        this.nombreOperations = nombreOperations;
    }

    public Integer getMois() {
        return mois;
    }

    public void setMois(Integer mois) {
        this.mois = mois;
    }

    public Integer getAnnee() {
        return annee;
    }

    public void setAnnee(Integer annee) {
        this.annee = annee;
    }

    public Boolean getPdfGenere() {
        return pdfGenere;
    }

    public void setPdfGenere(Boolean pdfGenere) {
        this.pdfGenere = pdfGenere;
    }

    public String getCheminPdf() {
        return cheminPdf;
    }

    public void setCheminPdf(String cheminPdf) {
        this.cheminPdf = cheminPdf;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public List<CompteBancaire> getComptes() {
        return comptes;
    }

    public void setComptes(List<CompteBancaire> comptes) {
        this.comptes = comptes;
    }
}
