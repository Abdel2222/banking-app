package com.banking.entities;

import com.banking.entity.enums.AccountStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "comptes_bancaires")
public class CompteBancaire {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Le numéro de compte est obligatoire")
    @Pattern(regexp = "^[0-9]{10,20}$", message = "Le numéro de compte doit contenir entre 10 et 20 chiffres")
    @Column(name = "num_compte", nullable = false, unique = true, length = 20)
    private String numCompte;

    @NotNull(message = "Le solde est obligatoire")
    @DecimalMin(value = "0.0", message = "Le solde doit être positif ou nul")
    @Column(name = "balance", nullable = false, precision = 15, scale = 2)
    private BigDecimal balance = BigDecimal.ZERO;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private AccountStatus status = AccountStatus.CREATED;

    // Relations
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_id", nullable = false)
    private Client client;

    @OneToMany(mappedBy = "compteBancaire", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Operation> operations = new ArrayList<>();

    @OneToOne(mappedBy = "compteBancaire", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private CarteBancaire carteBancaire;

    @OneToOne(mappedBy = "compteBancaire", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private CompteEpargne compteEpargne;

    @OneToMany(mappedBy = "compteSource", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Chat> chatsEnvoyes = new ArrayList<>();

    @OneToMany(mappedBy = "compteDestinataire", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Chat> chatsRecus = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "compte_releve",
            joinColumns = @JoinColumn(name = "compte_id"),
            inverseJoinColumns = @JoinColumn(name = "releve_id")
    )
    private List<ReleveDeCompte> releves = new ArrayList<>();

    // Constructeurs
    public CompteBancaire() {
        this.status = AccountStatus.CREATED;
        this.balance = BigDecimal.ZERO;
        this.createdAt = LocalDateTime.now();
    }

    public CompteBancaire(String numCompte, Client client) {
        this();
        this.numCompte = numCompte;
        this.client = client;
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (status == null) {
            status = AccountStatus.CREATED;
        }
    }

    // Méthodes métier
    public void crediter(BigDecimal montant) {
        if (montant == null || montant.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Le montant doit être positif");
        }
        if (!isActive()) {
            throw new IllegalStateException("Impossible de créditer un compte inactif");
        }
        this.balance = this.balance.add(montant);
    }

    public void debiter(BigDecimal montant) {
        if (montant == null || montant.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Le montant doit être positif");
        }
        if (!isActive()) {
            throw new IllegalStateException("Impossible de débiter un compte inactif");
        }
        if (this.balance.compareTo(montant) < 0) {
            throw new IllegalArgumentException("Solde insuffisant");
        }
        this.balance = this.balance.subtract(montant);
    }

    public boolean isActive() {
        return AccountStatus.ACTIVATED.equals(this.status);
    }

    public boolean estActif() {
        return isActive();
    }

    public void activate() {
        if (this.status == AccountStatus.CREATED) {
            this.status = AccountStatus.ACTIVATED;
        } else {
            throw new IllegalStateException("Le compte ne peut être activé que s'il est en état CREATED");
        }
    }

    public void suspend() {
        if (this.status == AccountStatus.ACTIVATED) {
            this.status = AccountStatus.SUSPENDED;
        } else {
            throw new IllegalStateException("Seul un compte actif peut être suspendu");
        }
    }

    public void close() {
        if (this.balance.compareTo(BigDecimal.ZERO) != 0) {
            throw new IllegalStateException("Impossible de fermer un compte avec un solde non nul");
        }
        this.status = AccountStatus.SUSPENDED;
    }

    // Méthodes pour gérer les relations
    public void addOperation(Operation operation) {
        operations.add(operation);
        operation.setCompteBancaire(this);
    }

    public void removeOperation(Operation operation) {
        operations.remove(operation);
        operation.setCompteBancaire(null);
    }

    public void setCarteBancaire(CarteBancaire carte) {
        this.carteBancaire = carte;
        if (carte != null) {
            carte.setCompteBancaire(this);
        }
    }

    public void addChatEnvoye(Chat chat) {
        chatsEnvoyes.add(chat);
        chat.setCompteSource(this);
    }

    public void addChatRecu(Chat chat) {
        chatsRecus.add(chat);
        chat.setCompteDestinataire(this);
    }

    public void addReleve(ReleveDeCompte releve) {
        if (!releves.contains(releve)) {
            releves.add(releve);
            releve.getComptes().add(this);
        }
    }

    // Méthodes equals, hashCode et toString
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CompteBancaire)) return false;
        CompteBancaire that = (CompteBancaire) o;
        return Objects.equals(numCompte, that.numCompte);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numCompte);
    }

    @Override
    public String toString() {
        return "CompteBancaire{" +
                "id=" + id +
                ", numCompte='" + numCompte + '\'' +
                ", balance=" + balance +
                ", status=" + status +
                ", createdAt=" + createdAt +
                '}';
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumCompte() {
        return numCompte;
    }

    public void setNumCompte(String numCompte) {
        this.numCompte = numCompte;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public AccountStatus getStatus() {
        return status;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public List<Operation> getOperations() {
        return operations;
    }

    public void setOperations(List<Operation> operations) {
        this.operations = operations;
    }

    public CarteBancaire getCarteBancaire() {
        return carteBancaire;
    }

    public CompteEpargne getCompteEpargne() {
        return compteEpargne;
    }

    public void setCompteEpargne(CompteEpargne compteEpargne) {
        this.compteEpargne = compteEpargne;
    }

    public List<Chat> getChatsEnvoyes() {
        return chatsEnvoyes;
    }

    public void setChatsEnvoyes(List<Chat> chatsEnvoyes) {
        this.chatsEnvoyes = chatsEnvoyes;
    }

    public List<Chat> getChatsRecus() {
        return chatsRecus;
    }

    public void setChatsRecus(List<Chat> chatsRecus) {
        this.chatsRecus = chatsRecus;
    }

    public List<ReleveDeCompte> getReleves() {
        return releves;
    }

    public void setReleves(List<ReleveDeCompte> releves) {
        this.releves = releves;
    }
}