package com.banking.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "comptes_epargne")
public class CompteEpargne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Le montant minimum est obligatoire")
    @DecimalMin(value = "0.0", message = "Le montant minimum ne peut pas être négatif")
    @Column(name = "montant_minimum", nullable = false, precision = 15, scale = 2)
    private BigDecimal montantMinimum = new BigDecimal("50.00");

    @NotNull(message = "Le taux d'intérêt est obligatoire")
    @DecimalMin(value = "0.0", message = "Le taux d'intérêt ne peut pas être négatif")
    @Column(name = "taux_interet", nullable = false, precision = 5, scale = 2)
    private BigDecimal tauxInteret = new BigDecimal("2.50"); // 2.50%

    @Column(name = "plafond_depot", precision = 15, scale = 2)
    private BigDecimal plafondDepot = new BigDecimal("22950.00"); // Plafond Livret A

    @Column(name = "derniere_capitalisation")
    private LocalDate derniereCapitalisation;

    @Column(name = "interets_cumules", precision = 15, scale = 2)
    private BigDecimal interetsCumules = BigDecimal.ZERO;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Relations
    @OneToOne
    @JoinColumn(name = "compte_bancaire_id", nullable = false, unique = true)
    private CompteBancaire compteBancaire;

    // Constructeurs
    public CompteEpargne() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.derniereCapitalisation = LocalDate.now();
    }

    public CompteEpargne(BigDecimal montantMinimum, BigDecimal tauxInteret, CompteBancaire compteBancaire) {
        this();
        this.montantMinimum = montantMinimum;
        this.tauxInteret = tauxInteret;
        this.compteBancaire = compteBancaire;
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        updatedAt = LocalDateTime.now();
        if (derniereCapitalisation == null) {
            derniereCapitalisation = LocalDate.now();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Méthodes métier
    public boolean respecteMontantMinimum() {
        if (compteBancaire == null) {
            return false;
        }
        return compteBancaire.getBalance().compareTo(montantMinimum) >= 0;
    }

    public boolean depassePlafond() {
        if (compteBancaire == null || plafondDepot == null) {
            return false;
        }
        return compteBancaire.getBalance().compareTo(plafondDepot) > 0;
    }

    public BigDecimal calculerInteretsAnnuels() {
        if (compteBancaire == null) {
            return BigDecimal.ZERO;
        }
        BigDecimal solde = compteBancaire.getBalance();
        // Intérêts = solde * (taux / 100)
        return solde.multiply(tauxInteret).divide(new BigDecimal("100"), 2, BigDecimal.ROUND_HALF_UP);
    }

    public BigDecimal calculerInteretsMensuels() {
        // Intérêts annuels / 12
        return calculerInteretsAnnuels().divide(new BigDecimal("12"), 2, BigDecimal.ROUND_HALF_UP);
    }

    public void capitaliserInterets() {
        BigDecimal interets = calculerInteretsAnnuels();
        this.interetsCumules = this.interetsCumules.add(interets);
        this.derniereCapitalisation = LocalDate.now();

        // Ajouter les intérêts au solde du compte
        if (compteBancaire != null) {
            BigDecimal nouveauSolde = compteBancaire.getBalance().add(interets);
            compteBancaire.setBalance(nouveauSolde);
        }
    }

    public int joursDepuisDerniereCapitalisation() {
        if (derniereCapitalisation == null) {
            return 0;
        }
        return (int) java.time.temporal.ChronoUnit.DAYS.between(derniereCapitalisation, LocalDate.now());
    }

    public boolean doitCapitaliser() {
        // Capitalisation annuelle (365 jours)
        return joursDepuisDerniereCapitalisation() >= 365;
    }

    // equals, hashCode et toString
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CompteEpargne)) return false;
        CompteEpargne that = (CompteEpargne) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "CompteEpargne{" +
                "id=" + id +
                ", montantMinimum=" + montantMinimum +
                ", tauxInteret=" + tauxInteret + "%" +
                ", plafondDepot=" + plafondDepot +
                ", interetsCumules=" + interetsCumules +
                ", respecteMontantMin=" + respecteMontantMinimum() +
                '}';
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getMontantMinimum() {
        return montantMinimum;
    }

    public void setMontantMinimum(BigDecimal montantMinimum) {
        this.montantMinimum = montantMinimum;
    }

    public BigDecimal getTauxInteret() {
        return tauxInteret;
    }

    public void setTauxInteret(BigDecimal tauxInteret) {
        this.tauxInteret = tauxInteret;
    }

    public BigDecimal getPlafondDepot() {
        return plafondDepot;
    }

    public void setPlafondDepot(BigDecimal plafondDepot) {
        this.plafondDepot = plafondDepot;
    }

    public LocalDate getDerniereCapitalisation() {
        return derniereCapitalisation;
    }

    public void setDerniereCapitalisation(LocalDate derniereCapitalisation) {
        this.derniereCapitalisation = derniereCapitalisation;
    }

    public BigDecimal getInteretsCumules() {
        return interetsCumules;
    }

    public void setInteretsCumules(BigDecimal interetsCumules) {
        this.interetsCumules = interetsCumules;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public CompteBancaire getCompteBancaire() {
        return compteBancaire;
    }

    public void setCompteBancaire(CompteBancaire compteBancaire) {
        this.compteBancaire = compteBancaire;
    }
}