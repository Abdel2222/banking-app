package com.banking.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "cartes_bancaires")
public class CarteBancaire {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Le numéro de carte est obligatoire")
    @Pattern(regexp = "^[0-9]{16}$", message = "Le numéro de carte doit contenir 16 chiffres")
    @Column(name = "numero_carte", nullable = false, unique = true, length = 16)
    private String numeroCarte;

    @NotNull(message = "La date d'expiration est obligatoire")
    @Column(name = "date_expiration", nullable = false)
    private LocalDate dateExpiration;

    @NotBlank(message = "Le code CVV est obligatoire")
    @Pattern(regexp = "^[0-9]{3}$", message = "Le CVV doit contenir 3 chiffres")
    @Column(name = "cvv", nullable = false, length = 3)
    private String cvv;

    @Column(name = "plafond_journalier", nullable = false)
    private Double plafondJournalier = 1000.0;

    @Column(name = "plafond_mensuel", nullable = false)
    private Double plafondMensuel = 3000.0;

    @Column(name = "est_active", nullable = false)
    private Boolean estActive = true;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Relations
    @OneToOne
    @JoinColumn(name = "compte_bancaire_id", nullable = false, unique = true)
    private CompteBancaire compteBancaire;

    // Constructeurs
    public CarteBancaire() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.estActive = true;
    }

    public CarteBancaire(String numeroCarte, LocalDate dateExpiration, String cvv, CompteBancaire compteBancaire) {
        this();
        this.numeroCarte = numeroCarte;
        this.dateExpiration = dateExpiration;
        this.cvv = cvv;
        this.compteBancaire = compteBancaire;
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Méthodes métier
    public boolean estExpiree() {
        return LocalDate.now().isAfter(dateExpiration);
    }

    public boolean estValide() {
        return estActive && !estExpiree();
    }

    public void bloquer() {
        this.estActive = false;
    }

    public void debloquer() {
        if (!estExpiree()) {
            this.estActive = true;
        } else {
            throw new IllegalStateException("Impossible de débloquer une carte expirée");
        }
    }

    public String getNumeroMasque() {
        if (numeroCarte == null || numeroCarte.length() != 16) {
            return "Invalid";
        }
        return "**** **** **** " + numeroCarte.substring(12);
    }

    public int getMoisAvantExpiration() {
        if (estExpiree()) {
            return 0;
        }
        LocalDate now = LocalDate.now();
        int mois = (dateExpiration.getYear() - now.getYear()) * 12;
        mois += dateExpiration.getMonthValue() - now.getMonthValue();
        return Math.max(0, mois);
    }

    // equals, hashCode et toString
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CarteBancaire)) return false;
        CarteBancaire that = (CarteBancaire) o;
        return Objects.equals(numeroCarte, that.numeroCarte);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroCarte);
    }

    @Override
    public String toString() {
        return "CarteBancaire{" +
                "id=" + id +
                ", numeroCarte='" + getNumeroMasque() + '\'' +
                ", dateExpiration=" + dateExpiration +
                ", estActive=" + estActive +
                ", estValide=" + estValide() +
                '}';
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumeroCarte() {
        return numeroCarte;
    }

    public void setNumeroCarte(String numeroCarte) {
        this.numeroCarte = numeroCarte;
    }

    public LocalDate getDateExpiration() {
        return dateExpiration;
    }

    public void setDateExpiration(LocalDate dateExpiration) {
        this.dateExpiration = dateExpiration;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public Double getPlafondJournalier() {
        return plafondJournalier;
    }

    public void setPlafondJournalier(Double plafondJournalier) {
        this.plafondJournalier = plafondJournalier;
    }

    public Double getPlafondMensuel() {
        return plafondMensuel;
    }

    public void setPlafondMensuel(Double plafondMensuel) {
        this.plafondMensuel = plafondMensuel;
    }

    public Boolean getEstActive() {
        return estActive;
    }

    public void setEstActive(Boolean estActive) {
        this.estActive = estActive;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public CompteBancaire getCompteBancaire() {
        return compteBancaire;
    }

    public void setCompteBancaire(CompteBancaire compteBancaire) {
        this.compteBancaire = compteBancaire;
    }
}