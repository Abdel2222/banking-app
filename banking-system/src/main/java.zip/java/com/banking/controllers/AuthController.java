package com.banking.controllers;

import com.banking.dto.request.*;
import com.banking.dto.response.*;
import com.banking.entities.Client;
import com.banking.services.ClientService;
import com.banking.exceptions.DuplicateResourceException;
import com.banking.exceptions.UnauthorizedAccessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {

    @Autowired
    private ClientService clientService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<ClientResponse>> register(
            @Valid @RequestBody ClientRegistrationRequest request) {

        if (clientService.emailExists(request.getEmail())) {
            throw new DuplicateResourceException("Client", "email", request.getEmail());
        }

        Client client = clientService.createClient(
                request.getPrenom(),
                request.getNom(),
                request.getEmail(),
                request.getMotDePasse()
        );

        ClientResponse response = new ClientResponse(client);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Inscription réussie", response));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(
            @Valid @RequestBody LoginRequest request) {

        Optional<Client> clientOpt = clientService.authenticate(
                request.getEmail(),
                request.getMotDePasse()
        );

        if (clientOpt.isPresent()) {
            Client client = clientOpt.get();

            // TODO: Implémenter JWT
            String token = "temporary-token-" + client.getId();

            LoginResponse response = new LoginResponse(
                    token,
                    client.getId(),
                    client.getEmail(),
                    client.getNomComplet(),
                    client.getRole()
            );

            return ResponseEntity.ok(ApiResponse.success("Connexion réussie", response));
        } else {
            throw new UnauthorizedAccessException("Email ou mot de passe incorrect");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<MessageResponse>> logout() {
        // TODO: Invalider le token JWT
        return ResponseEntity.ok(
                ApiResponse.success("Déconnexion réussie", new MessageResponse("Vous êtes déconnecté"))
        );
    }

    @GetMapping("/check-email")
    public ResponseEntity<ApiResponse<Boolean>> checkEmail(@RequestParam String email) {
        boolean exists = clientService.emailExists(email);
        String message = exists ? "Email déjà utilisé" : "Email disponible";
        return ResponseEntity.ok(ApiResponse.success(message, !exists));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<MessageResponse>> forgotPassword(
            @RequestBody EmailRequest request) {

        // Ne pas révéler si l'email existe pour des raisons de sécurité
        Optional<Client> client = clientService.findByEmail(request.getEmail());

        // TODO: Implémenter l'envoi d'email
        // if (client.isPresent()) {
        //     emailService.sendResetPasswordEmail(request.getEmail(), resetToken);
        // }

        return ResponseEntity.ok(ApiResponse.success(
                "Si cet email existe, un lien de réinitialisation a été envoyé",
                new MessageResponse("Vérifiez votre boîte mail")
        ));
    }

    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<MessageResponse>> changePassword(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody ChangePasswordRequest request) {

        // TODO: Extraire l'ID du client depuis le token JWT
        Long clientId = 1L; // Temporaire

        boolean success = clientService.changePassword(
                clientId,
                request.getOldPassword(),
                request.getNewPassword()
        );

        if (success) {
            return ResponseEntity.ok(
                    ApiResponse.success("Mot de passe changé avec succès",
                            new MessageResponse("Mot de passe mis à jour"))
            );
        } else {
            throw new UnauthorizedAccessException("Ancien mot de passe incorrect");
        }
    }

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<ClientResponse>> getCurrentUser(
            @RequestHeader("Authorization") String token) {

        // TODO: Extraire l'ID du client depuis le token JWT
        Long clientId = 1L; // Temporaire

        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new UnauthorizedAccessException("Utilisateur non trouvé"));

        return ResponseEntity.ok(ApiResponse.success(new ClientResponse(client)));
    }

    @PutMapping("/me")
    public ResponseEntity<ApiResponse<ClientResponse>> updateProfile(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody UpdateProfileRequest request) {

        // TODO: Extraire l'ID du client depuis le token JWT
        Long clientId = 1L; // Temporaire

        Client clientDetails = new Client();
        clientDetails.setPrenom(request.getPrenom());
        clientDetails.setNom(request.getNom());
        clientDetails.setEmail(request.getEmail());

        Client updatedClient = clientService.updateClient(clientId, clientDetails);

        return ResponseEntity.ok(
                ApiResponse.success("Profil mis à jour avec succès", new ClientResponse(updatedClient))
        );
    }
}

