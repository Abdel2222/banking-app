package com.banking.controllers;

import com.banking.dto.request.*;
import com.banking.dto.response.*;
import com.banking.entities.CompteBancaire;
import com.banking.entities.Operation;
import com.banking.entity.enums.AccountStatus;
import com.banking.services.CompteBancaireService;
import com.banking.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/accounts")
@CrossOrigin(origins = "*", maxAge = 3600)
public class CompteBancaireController {

    @Autowired
    private CompteBancaireService compteBancaireService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<AccountResponse>>> getAllAccounts() {
        List<AccountResponse> accounts = compteBancaireService.findAll().stream()
                .map(AccountResponse::new)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.success(accounts));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<AccountResponse>> getAccountById(@PathVariable Long id) {
        CompteBancaire compte = compteBancaireService.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "id", id));

        return ResponseEntity.ok(ApiResponse.success(new AccountResponse(compte)));
    }

    @GetMapping("/number/{numCompte}")
    public ResponseEntity<ApiResponse<AccountResponse>> getAccountByNumber(@PathVariable String numCompte) {
        CompteBancaire compte = compteBancaireService.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return ResponseEntity.ok(ApiResponse.success(new AccountResponse(compte)));
    }

    @GetMapping("/{numCompte}/balance")
    public ResponseEntity<ApiResponse<BigDecimal>> getBalance(@PathVariable String numCompte) {
        BigDecimal balance = compteBancaireService.getBalance(numCompte);
        return ResponseEntity.ok(ApiResponse.success("Solde récupéré", balance));
    }

    @PostMapping("/{numCompte}/deposit")
    public ResponseEntity<ApiResponse<OperationResponse>> deposit(
            @PathVariable String numCompte,
            @Valid @RequestBody TransactionRequest request) {

        Operation operation = compteBancaireService.deposit(
                numCompte,
                request.getMontant(),
                request.getDescription()
        );

        return ResponseEntity.ok(
                ApiResponse.success("Dépôt effectué avec succès", new OperationResponse(operation))
        );
    }

    @PostMapping("/{numCompte}/withdraw")
    public ResponseEntity<ApiResponse<OperationResponse>> withdraw(
            @PathVariable String numCompte,
            @Valid @RequestBody TransactionRequest request) {

        Operation operation = compteBancaireService.withdraw(
                numCompte,
                request.getMontant(),
                request.getDescription()
        );

        return ResponseEntity.ok(
                ApiResponse.success("Retrait effectué avec succès", new OperationResponse(operation))
        );
    }

    @PostMapping("/transfer")
    public ResponseEntity<ApiResponse<OperationResponse>> transfer(
            @Valid @RequestBody TransferRequest request) {

        Operation operation = compteBancaireService.transfer(
                request.getNumCompteSource(),
                request.getNumCompteDestinataire(),
                request.getMontant(),
                request.getCommunication()
        );

        return ResponseEntity.ok(
                ApiResponse.success("Virement effectué avec succès", new OperationResponse(operation))
        );
    }

    @PutMapping("/{numCompte}/activate")
    public ResponseEntity<ApiResponse<AccountResponse>> activateAccount(@PathVariable String numCompte) {
        CompteBancaire compte = compteBancaireService.activateAccount(numCompte);
        return ResponseEntity.ok(
                ApiResponse.success("Compte activé avec succès", new AccountResponse(compte))
        );
    }

    @PutMapping("/{numCompte}/suspend")
    public ResponseEntity<ApiResponse<AccountResponse>> suspendAccount(@PathVariable String numCompte) {
        CompteBancaire compte = compteBancaireService.suspendAccount(numCompte);
        return ResponseEntity.ok(
                ApiResponse.success("Compte suspendu avec succès", new AccountResponse(compte))
        );
    }

    @PutMapping("/{numCompte}/close")
    public ResponseEntity<ApiResponse<AccountResponse>> closeAccount(@PathVariable String numCompte) {
        CompteBancaire compte = compteBancaireService.closeAccount(numCompte);
        return ResponseEntity.ok(
                ApiResponse.success("Compte fermé avec succès", new AccountResponse(compte))
        );
    }

    @GetMapping("/{numCompte}/history")
    public ResponseEntity<ApiResponse<List<OperationResponse>>> getAccountHistory(
            @PathVariable String numCompte,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {

        List<OperationResponse> operations = compteBancaireService
                .getAccountHistory(numCompte, start, end).stream()
                .map(OperationResponse::new)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.success(operations));
    }

    @GetMapping("/{numCompte}/operations/last/{count}")
    public ResponseEntity<ApiResponse<List<OperationResponse>>> getLastOperations(
            @PathVariable String numCompte,
            @PathVariable int count) {

        List<OperationResponse> operations = compteBancaireService
                .getLastOperations(numCompte, count).stream()
                .map(OperationResponse::new)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.success(operations));
    }

    @PostMapping("/{numCompte}/card/issue")
    public ResponseEntity<ApiResponse<MessageResponse>> issueCard(@PathVariable String numCompte) {
        compteBancaireService.issueCard(numCompte);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success("Carte émise avec succès",
                        new MessageResponse("Carte bancaire créée pour le compte " + numCompte))
        );
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<AccountResponse>>> getAccountsByStatus(
            @PathVariable AccountStatus status) {

        List<AccountResponse> accounts = compteBancaireService.findByStatus(status).stream()
                .map(AccountResponse::new)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.success(accounts));
    }
}