package com.banking.controllers;

import com.banking.entities.CompteEpargne;
import com.banking.services.CompteEpargneService;
import com.banking.dto.response.ApiResponse;
import com.banking.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/savings")
@CrossOrigin(origins = "*", maxAge = 3600)
public class CompteEpargneController {

    @Autowired
    private CompteEpargneService compteEpargneService;

    @GetMapping("/compte/{compteId}")
    public ResponseEntity<ApiResponse<CompteEpargne>> getSavingsByCompteId(@PathVariable Long compteId) {
        CompteEpargne epargne = compteEpargneService.findByCompteId(compteId);
        return ResponseEntity.ok(ApiResponse.success("Compte épargne trouvé", epargne));
    }

    @GetMapping("/{numCompte}/interets")
    public ResponseEntity<ApiResponse<BigDecimal>> calculerInterets(@PathVariable String numCompte) {
        BigDecimal interets = compteEpargneService.calculerInterets(numCompte);
        return ResponseEntity.ok(ApiResponse.success("Intérêts calculés", interets));
    }

    @PostMapping("/{numCompte}/capitaliser")
    public ResponseEntity<ApiResponse<String>> capitaliserInterets(@PathVariable String numCompte) {
        compteEpargneService.capitaliserInterets(numCompte);
        return ResponseEntity.ok(ApiResponse.success("Capitalisation effectuée"));
    }

    @GetMapping("/{numCompte}/doit-capitaliser")
    public ResponseEntity<ApiResponse<Boolean>> doitCapitaliser(@PathVariable String numCompte) {
        boolean resultat = compteEpargneService.doitCapitaliser(numCompte);
        return ResponseEntity.ok(ApiResponse.success("Nécessite capitalisation ?", resultat));
    }
}
