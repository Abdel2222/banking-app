// CarteBancaireRepository.java
package com.banking.repositories;

import com.banking.entities.CarteBancaire;
import com.banking.entities.CompteBancaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CarteBancaireRepository extends JpaRepository<CarteBancaire, Long> {

    Optional<CarteBancaire> findByNumeroCarte(String numeroCarte);

    Optional<CarteBancaire> findByCompteBancaire(CompteBancaire compteBancaire);

    List<CarteBancaire> findByEstActive(Boolean estActive);

    @Query("SELECT c FROM CarteBancaire c WHERE c.dateExpiration < :date")
    List<CarteBancaire> findExpiredCards(LocalDate date);

    @Query("SELECT c FROM CarteBancaire c WHERE c.dateExpiration BETWEEN :now AND :future")
    List<CarteBancaire> findCardsExpiringSoon(LocalDate now, LocalDate future);
}

