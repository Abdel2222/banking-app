// ChatRepository.java
package com.banking.repositories;

import com.banking.entities.Chat;
import com.banking.entities.CompteBancaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChatRepository extends JpaRepository<Chat, Long> {

    List<Chat> findByCompteSource(CompteBancaire compteSource);

    List<Chat> findByCompteDestinataire(CompteBancaire compteDestinataire);

    @Query("SELECT c FROM Chat c WHERE c.compteSource = :compte OR c.compteDestinataire = :compte " +
            "ORDER BY c.createdAt DESC")
    List<Chat> findAllChatsForAccount(@Param("compte") CompteBancaire compte);

    @Query("SELECT c FROM Chat c WHERE c.reponse IS NULL")
    List<Chat> findUnansweredChats();

    @Query("SELECT c FROM Chat c WHERE c.luParDestinataire = false AND c.compteDestinataire IS NOT NULL")
    List<Chat> findUnreadChats();
}