package com.banking.repositories;

import com.banking.entities.ReleveDeCompte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReleveDeCompteRepository extends JpaRepository<ReleveDeCompte, Long> {

    List<ReleveDeCompte> findByMoisAndAnnee(Integer mois, Integer annee);

    @Query("SELECT r FROM ReleveDeCompte r JOIN r.comptes c WHERE c.id = :compteId")
    List<ReleveDeCompte> findByCompteId(@Param("compteId") Long compteId);

    List<ReleveDeCompte> findByPdfGenere(Boolean pdfGenere);

    @Query("SELECT r FROM ReleveDeCompte r WHERE r.annee = :annee ORDER BY r.mois")
    List<ReleveDeCompte> findByYear(@Param("annee") Integer annee);
}
