package com.banking.repositories;

import com.banking.entities.CompteBancaire;
import com.banking.entities.Operation;
import com.banking.entity.enums.TypeOperation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OperationRepository extends JpaRepository<Operation, Long> {

    // Opérations par compte
    List<Operation> findByCompteBancaire(CompteBancaire compteBancaire);

    // Opérations par compte avec pagination
    Page<Operation> findByCompteBancaire(CompteBancaire compteBancaire, Pageable pageable);

    // Opérations par type
    List<Operation> findByType(TypeOperation type);

    // Opérations entre deux dates
    List<Operation> findByDateOperationBetween(LocalDateTime start, LocalDateTime end);

    // Opérations d'un compte entre deux dates
    @Query("SELECT o FROM Operation o WHERE o.compteBancaire = :compte " +
            "AND o.dateOperation BETWEEN :start AND :end ORDER BY o.dateOperation DESC")
    List<Operation> findByCompteAndDateBetween(@Param("compte") CompteBancaire compte,
                                               @Param("start") LocalDateTime start,
                                               @Param("end") LocalDateTime end);

    // Virements vers un compte destinataire
    @Query("SELECT o FROM Operation o WHERE o.type = 'VIREMENT' " +
            "AND o.numeroCompteDestinataire = :numeroCompte")
    List<Operation> findTransfersToAccount(@Param("numeroCompte") String numeroCompte);

    // Somme des dépôts pour un compte
    @Query("SELECT SUM(o.montant) FROM Operation o WHERE o.compteBancaire = :compte " +
            "AND o.type = 'DEPOT'")
    BigDecimal sumDepositsByAccount(@Param("compte") CompteBancaire compte);

    // Somme des retraits pour un compte
    @Query("SELECT SUM(o.montant) FROM Operation o WHERE o.compteBancaire = :compte " +
            "AND o.type = 'RETRAIT'")
    BigDecimal sumWithdrawalsByAccount(@Param("compte") CompteBancaire compte);

    // Dernières opérations d'un compte
    @Query("SELECT o FROM Operation o WHERE o.compteBancaire = :compte " +
            "ORDER BY o.dateOperation DESC")
    List<Operation> findLastOperations(@Param("compte") CompteBancaire compte, Pageable pageable);

    // Opérations avec montant supérieur à
    List<Operation> findByMontantGreaterThan(BigDecimal montant);

    // Opérations nécessitant validation
    @Query("SELECT o FROM Operation o WHERE o.type IN ('VIREMENT', 'BLOCAGE_CARTE') " +
            "AND o.dateOperation > :date")
    List<Operation> findOperationsNeedingValidation(@Param("date") LocalDateTime date);

    // Statistiques par type d'opération
    @Query("SELECT o.type, COUNT(o), SUM(o.montant) FROM Operation o " +
            "WHERE o.dateOperation BETWEEN :start AND :end GROUP BY o.type")
    List<Object[]> getStatisticsByType(@Param("start") LocalDateTime start,
                                       @Param("end") LocalDateTime end);
}