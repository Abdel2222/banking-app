package com.banking.repositories;

import com.banking.entities.CompteBancaire;
import com.banking.entities.Client;
import com.banking.entity.enums.AccountStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface CompteBancaireRepository extends JpaRepository<CompteBancaire, Long> {

    // Recherche par numéro de compte
    Optional<CompteBancaire> findByNumCompte(String numCompte);

    // Vérifier si un numéro de compte existe
    boolean existsByNumCompte(String numCompte);

    // Comptes par client
    List<CompteBancaire> findByClient(Client client);

    // Comptes par statut
    List<CompteBancaire> findByStatus(AccountStatus status);

    // Comptes actifs
    @Query("SELECT c FROM CompteBancaire c WHERE c.status = 'ACTIVATED'")
    List<CompteBancaire> findActiveAccounts();

    // Comptes avec solde supérieur à
    List<CompteBancaire> findByBalanceGreaterThan(BigDecimal balance);

    // Comptes créés entre deux dates
    List<CompteBancaire> findByCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    // Comptes avec carte bancaire
    @Query("SELECT c FROM CompteBancaire c WHERE c.carteBancaire IS NOT NULL")
    List<CompteBancaire> findAccountsWithCard();

    // Comptes épargne
    @Query("SELECT c FROM CompteBancaire c WHERE c.compteEpargne IS NOT NULL")
    List<CompteBancaire> findSavingsAccounts();

    // Solde total de tous les comptes
    @Query("SELECT SUM(c.balance) FROM CompteBancaire c")
    BigDecimal getTotalBalance();

    // Solde moyen
    @Query("SELECT AVG(c.balance) FROM CompteBancaire c")
    BigDecimal getAverageBalance();

    // Comptes à découvert (si on gère les découverts)
    @Query("SELECT c FROM CompteBancaire c WHERE c.balance < 0")
    List<CompteBancaire> findOverdrawnAccounts();

    // Comptes inactifs depuis plus de X jours
    @Query("SELECT c FROM CompteBancaire c WHERE c.status != 'ACTIVATED' " +
            "AND c.createdAt < :date")
    List<CompteBancaire> findInactiveAccountsOlderThan(@Param("date") LocalDateTime date);
}