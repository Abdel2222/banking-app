package com.banking.repositories;

import com.banking.entities.CompteBancaire;
import com.banking.entities.CompteEpargne;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CompteEpargneRepository extends JpaRepository<CompteEpargne, Long> {

    Optional<CompteEpargne> findByCompteBancaire(CompteBancaire compteBancaire);

    List<CompteEpargne> findByTauxInteretGreaterThan(BigDecimal taux);

    @Query("SELECT ce FROM CompteEpargne ce WHERE ce.compteBancaire.balance > ce.plafondDepot")
    List<CompteEpargne> findAccountsExceedingCeiling();

    @Query("SELECT ce FROM CompteEpargne ce WHERE ce.derniereCapitalisation <= :limitDate")
    List<CompteEpargne> findAccountsNeedingCapitalization(LocalDate limitDate);
}
