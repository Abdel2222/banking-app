package com.banking.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * DTO pour la création d'un nouveau compte bancaire
 */
public class CreateAccountRequest {

    @NotBlank(message = "Le type de compte est obligatoire")
    @Pattern(regexp = "^(COURANT|EPARGNE|PROFESSIONNEL)$",
            message = "Le type de compte doit être COURANT, EPARGNE ou PROFESSIONNEL")
    private String typeCompte;

    // Valeur par défaut
    public CreateAccountRequest() {
        this.typeCompte = "COURANT";
    }

    // Constructeur avec paramètre
    public CreateAccountRequest(String typeCompte) {
        this.typeCompte = typeCompte;
    }

    // Getter
    public String getTypeCompte() {
        return typeCompte;
    }

    // Setter
    public void setTypeCompte(String typeCompte) {
        this.typeCompte = typeCompte;
    }

    @Override
    public String toString() {
        return "CreateAccountRequest{" +
                "typeCompte='" + typeCompte + '\'' +
                '}';
    }
}
