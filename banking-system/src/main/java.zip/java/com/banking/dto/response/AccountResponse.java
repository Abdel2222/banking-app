package com.banking.dto.response;

import com.banking.entities.CompteBancaire;
import com.banking.entity.enums.AccountStatus;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class AccountResponse {
    private Long id;
    private String numCompte;
    private BigDecimal balance;
    private AccountStatus status;
    private String clientName;
    private boolean hasCard;
    private boolean isSavingsAccount;
    private LocalDateTime createdAt;

    public AccountResponse(CompteBancaire compte) {
        this.id = compte.getId();
        this.numCompte = compte.getNumCompte();
        this.balance = compte.getBalance();
        this.status = compte.getStatus();
        this.clientName = compte.getClient().getNomComplet();
        this.hasCard = compte.getCarteBancaire() != null;
        this.isSavingsAccount = compte.getCompteEpargne() != null;
        this.createdAt = compte.getCreatedAt();
    }

    // Getters
    public Long getId() { return id; }
    public String getNumCompte() { return numCompte; }
    public BigDecimal getBalance() { return balance; }
    public AccountStatus getStatus() { return status; }
    public String getClientName() { return clientName; }
    public boolean isHasCard() { return hasCard; }
    public boolean isSavingsAccount() { return isSavingsAccount; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
