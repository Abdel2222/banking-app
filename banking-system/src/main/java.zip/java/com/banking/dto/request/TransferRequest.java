package com.banking.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.math.BigDecimal;

public class TransferRequest {

    @NotBlank(message = "Le compte source est obligatoire")
    @Pattern(regexp = "^[0-9]{10,20}$", message = "Numéro de compte source invalide")
    private String numCompteSource;

    @NotBlank(message = "Le compte destinataire est obligatoire")
    @Pattern(regexp = "^[0-9]{10,20}$", message = "Numéro de compte destinataire invalide")
    private String numCompteDestinataire;

    @NotNull(message = "Le montant est obligatoire")
    @DecimalMin(value = "0.01", message = "Le montant doit être supérieur à 0")
    private BigDecimal montant;

    private String communication;

    // Getters et Setters
    public String getNumCompteSource() { return numCompteSource; }
    public void setNumCompteSource(String numCompteSource) {
        this.numCompteSource = numCompteSource;
    }

    public String getNumCompteDestinataire() { return numCompteDestinataire; }
    public void setNumCompteDestinataire(String numCompteDestinataire) {
        this.numCompteDestinataire = numCompteDestinataire;
    }

    public BigDecimal getMontant() { return montant; }
    public void setMontant(BigDecimal montant) { this.montant = montant; }

    public String getCommunication() { return communication; }
    public void setCommunication(String communication) { this.communication = communication; }
}
