package com.banking.dto.response;

import com.banking.entities.Operation;
import com.banking.entity.enums.TypeOperation;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class OperationResponse {
    private Long id;
    private LocalDateTime dateOperation;
    private BigDecimal montant;
    private TypeOperation type;
    private String description;
    private String numeroCompte;
    private String numeroCompteDestinataire;
    private String communication;

    public OperationResponse(Operation operation) {
        this.id = operation.getId();
        this.dateOperation = operation.getDateOperation();
        this.montant = operation.getMontant();
        this.type = operation.getType();
        this.description = operation.getDescriptionOperation();
        this.numeroCompte = operation.getCompteBancaire().getNumCompte();
        this.numeroCompteDestinataire = operation.getNumeroCompteDestinataire();
        this.communication = operation.getCommunication();
    }

    // Getters
    public Long getId() { return id; }
    public LocalDateTime getDateOperation() { return dateOperation; }
    public BigDecimal getMontant() { return montant; }
    public TypeOperation getType() { return type; }
    public String getDescription() { return description; }
    public String getNumeroCompte() { return numeroCompte; }
    public String getNumeroCompteDestinataire() { return numeroCompteDestinataire; }
    public String getCommunication() { return communication; }
}

