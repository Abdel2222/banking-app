package com.banking.services.impl;

import com.banking.entities.CompteBancaire;
import com.banking.entities.CompteEpargne;
import com.banking.repositories.CompteBancaireRepository;
import com.banking.repositories.CompteEpargneRepository;
import com.banking.services.CompteEpargneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class CompteEpargneServiceImpl implements CompteEpargneService {

    @Autowired
    private CompteEpargneRepository compteEpargneRepository;

    @Autowired
    private CompteBancaireRepository compteBancaireRepository;

    @Override
    public CompteEpargne findByCompteId(Long compteId) {
        CompteBancaire compte = compteBancaireRepository.findById(compteId)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé avec l'ID: " + compteId));

        return compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Compte épargne non trouvé pour le compte ID: " + compteId));
    }

    @Override
    public BigDecimal calculerInterets(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé: " + numCompte));

        CompteEpargne epargne = compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Ce n'est pas un compte épargne"));

        return epargne.calculerInteretsAnnuels();
    }

    @Override
    public void capitaliserInterets(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé: " + numCompte));

        CompteEpargne epargne = compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Ce n'est pas un compte épargne"));

        if (epargne.doitCapitaliser()) {
            epargne.capitaliserInterets();
            compteEpargneRepository.save(epargne);
            compteBancaireRepository.save(compte);
        }
    }

    @Override
    public boolean doitCapitaliser(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé: " + numCompte));

        CompteEpargne epargne = compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Ce n'est pas un compte épargne"));

        return epargne.doitCapitaliser();
    }

    // Méthode pour rechercher tous les comptes devant capitaliser
    public List<CompteEpargne> findAllEpargnesADateDeCapitalisationDepassee() {
        LocalDate dateLimite = LocalDate.now().minusDays(365);
        return compteEpargneRepository.findAccountsNeedingCapitalization(dateLimite);
    }
}
