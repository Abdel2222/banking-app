package com.banking.services.impl;

import com.banking.entities.CompteBancaire;
import com.banking.entities.Operation;
import com.banking.entity.enums.TypeOperation;
import com.banking.exceptions.InvalidOperationException;
import com.banking.exceptions.ResourceNotFoundException;
import com.banking.repositories.CompteBancaireRepository;
import com.banking.repositories.OperationRepository;
import com.banking.services.CompteBancaireService;
import com.banking.services.OperationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class OperationServiceImpl implements OperationService {

    @Autowired
    private OperationRepository operationRepository;

    @Autowired
    private CompteBancaireRepository compteBancaireRepository;

    @Autowired
    private CompteBancaireService compteBancaireService;

    @Override
    public Operation createOperation(String numCompte, BigDecimal montant, TypeOperation type, String description) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        Operation operation = new Operation(compte, montant, type, description);
        return operationRepository.save(operation);
    }

    @Override
    public Optional<Operation> findById(Long id) {
        return operationRepository.findById(id);
    }

    @Override
    public List<Operation> findAll() {
        return operationRepository.findAll();
    }

    @Override
    public Page<Operation> findAllPaginated(Pageable pageable) {
        return operationRepository.findAll(pageable);
    }

    @Override
    public Operation executeDeposit(String numCompte, BigDecimal montant, String description) {
        return compteBancaireService.deposit(numCompte, montant, description);
    }

    @Override
    public Operation executeWithdrawal(String numCompte, BigDecimal montant, String description) {
        return compteBancaireService.withdraw(numCompte, montant, description);
    }

    @Override
    public Operation executeTransfer(String fromAccount, String toAccount, BigDecimal montant, String communication) {
        return compteBancaireService.transfer(fromAccount, toAccount, montant, communication);
    }

    @Override
    public Operation executeCardBlock(String numCompte, String raison) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        compteBancaireService.blockCard(numCompte, raison);

        Operation operation = new Operation(compte, BigDecimal.ZERO, TypeOperation.BLOCAGE_CARTE, raison);
        return operationRepository.save(operation);
    }

    @Override
    public List<Operation> findByAccount(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteBancaire(compte);
    }

    @Override
    public Page<Operation> findByAccountPaginated(String numCompte, Pageable pageable) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteBancaire(compte, pageable);
    }

    @Override
    public List<Operation> findByType(TypeOperation type) {
        return operationRepository.findByType(type);
    }

    @Override
    public List<Operation> findByDateRange(LocalDateTime start, LocalDateTime end) {
        return operationRepository.findByDateOperationBetween(start, end);
    }

    @Override
    public List<Operation> findByAccountAndDateRange(String numCompte, LocalDateTime start, LocalDateTime end) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteAndDateBetween(compte, start, end);
    }

    @Override
    public List<Operation> findLargeTransactions(BigDecimal minAmount) {
        return operationRepository.findByMontantGreaterThan(minAmount);
    }

    @Override
    public List<Operation> findSuspiciousTransactions() {
        // Logique pour détecter les transactions suspectes
        BigDecimal largeAmount = new BigDecimal("10000");
        LocalDateTime last24Hours = LocalDateTime.now().minusHours(24);

        List<Operation> suspicious = new ArrayList<>();

        // Transactions importantes récentes
        suspicious.addAll(operationRepository.findByDateOperationBetween(last24Hours, LocalDateTime.now())
                .stream()
                .filter(op -> op.getMontant().compareTo(largeAmount) > 0)
                .collect(Collectors.toList()));

        // Multiples retraits rapprochés
        Map<CompteBancaire, List<Operation>> retraitsByAccount = operationRepository
                .findByDateOperationBetween(last24Hours, LocalDateTime.now())
                .stream()
                .filter(op -> op.getType() == TypeOperation.RETRAIT)
                .collect(Collectors.groupingBy(Operation::getCompteBancaire));

        for (Map.Entry<CompteBancaire, List<Operation>> entry : retraitsByAccount.entrySet()) {
            if (entry.getValue().size() > 5) {
                suspicious.addAll(entry.getValue());
            }
        }

        return suspicious.stream().distinct().collect(Collectors.toList());
    }

    @Override
    public List<Operation> findTransfersToAccount(String numCompte) {
        return operationRepository.findTransfersToAccount(numCompte);
    }

    @Override
    public List<Operation> findTransfersFromAccount(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteBancaire(compte).stream()
                .filter(op -> op.getType() == TypeOperation.VIREMENT)
                .collect(Collectors.toList());
    }

    @Override
    public List<Operation> findRecurringTransactions(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        List<Operation> allOperations = operationRepository.findByCompteBancaire(compte);

        // Grouper par montant et destinataire pour identifier les récurrences
        Map<String, List<Operation>> grouped = allOperations.stream()
                .filter(op -> op.getNumeroCompteDestinataire() != null)
                .collect(Collectors.groupingBy(op ->
                        op.getMontant() + "-" + op.getNumeroCompteDestinataire()
                ));

        return grouped.values().stream()
                .filter(list -> list.size() > 1)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    @Override
    public Map<TypeOperation, BigDecimal> getStatisticsByType(LocalDateTime start, LocalDateTime end) {
        List<Object[]> stats = operationRepository.getStatisticsByType(start, end);
        Map<TypeOperation, BigDecimal> result = new HashMap<>();

        for (Object[] stat : stats) {
            result.put((TypeOperation) stat[0], (BigDecimal) stat[2]);
        }

        return result;
    }

    @Override
    public BigDecimal getTotalDeposits(String numCompte, LocalDateTime start, LocalDateTime end) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteAndDateBetween(compte, start, end).stream()
                .filter(op -> op.getType() == TypeOperation.DEPOT)
                .map(Operation::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    public BigDecimal getTotalWithdrawals(String numCompte, LocalDateTime start, LocalDateTime end) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteAndDateBetween(compte, start, end).stream()
                .filter(op -> op.getType() == TypeOperation.RETRAIT)
                .map(Operation::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    public BigDecimal getTotalTransfers(String numCompte, LocalDateTime start, LocalDateTime end) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        return operationRepository.findByCompteAndDateBetween(compte, start, end).stream()
                .filter(op -> op.getType() == TypeOperation.VIREMENT)
                .map(Operation::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    public Map<String, Object> getMonthlyReport(String numCompte, int month, int year) {
        LocalDateTime start = LocalDateTime.of(year, month, 1, 0, 0);
        LocalDateTime end = start.plusMonths(1).minusSeconds(1);

        Map<String, Object> report = new HashMap<>();
        report.put("month", month);
        report.put("year", year);
        report.put("accountNumber", numCompte);
        report.put("totalDeposits", getTotalDeposits(numCompte, start, end));
        report.put("totalWithdrawals", getTotalWithdrawals(numCompte, start, end));
        report.put("totalTransfers", getTotalTransfers(numCompte, start, end));

        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", "numéro", numCompte));

        report.put("currentBalance", compte.getBalance());
        report.put("operationsCount", operationRepository.findByCompteAndDateBetween(compte, start, end).size());

        return report;
    }

    @Override
    public boolean validateOperation(Operation operation) {
        if (operation == null) return false;
        if (operation.getMontant() == null || operation.getMontant().compareTo(BigDecimal.ZERO) <= 0) return false;
        if (operation.getType() == null) return false;
        if (operation.getCompteBancaire() == null) return false;

        return true;
    }

    @Override
    public boolean canExecuteOperation(String numCompte, BigDecimal montant, TypeOperation type) {
        return compteBancaireService.canPerformOperation(numCompte, montant);
    }

    @Override
    public boolean isDuplicateOperation(Operation operation) {
        LocalDateTime fiveMinutesAgo = LocalDateTime.now().minusMinutes(5);

        List<Operation> recentOps = operationRepository.findByCompteAndDateBetween(
                operation.getCompteBancaire(),
                fiveMinutesAgo,
                LocalDateTime.now()
        );

        return recentOps.stream().anyMatch(op ->
                op.getMontant().equals(operation.getMontant()) &&
                        op.getType().equals(operation.getType()) &&
                        Objects.equals(op.getNumeroCompteDestinataire(), operation.getNumeroCompteDestinataire())
        );
    }

    @Override
    public Operation cancelOperation(Long operationId, String raison) {
        Operation operation = operationRepository.findById(operationId)
                .orElseThrow(() -> new ResourceNotFoundException("Operation", "id", operationId));

        // Créer une opération d'annulation (inverse)
        return reverseOperation(operationId);
    }

    @Override
    public Operation reverseOperation(Long operationId) {
        Operation original = operationRepository.findById(operationId)
                .orElseThrow(() -> new ResourceNotFoundException("Operation", "id", operationId));

        Operation reverse = new Operation();
        reverse.setCompteBancaire(original.getCompteBancaire());
        reverse.setDateOperation(LocalDateTime.now());

        // Inverser le type d'opération
        if (original.getType() == TypeOperation.DEPOT) {
            reverse.setType(TypeOperation.RETRAIT);
            reverse.setMontant(original.getMontant());
            compteBancaireService.withdraw(
                    original.getCompteBancaire().getNumCompte(),
                    original.getMontant(),
                    "Annulation dépôt #" + original.getId()
            );
        } else if (original.getType() == TypeOperation.RETRAIT) {
            reverse.setType(TypeOperation.DEPOT);
            reverse.setMontant(original.getMontant());
            compteBancaireService.deposit(
                    original.getCompteBancaire().getNumCompte(),
                    original.getMontant(),
                    "Annulation retrait #" + original.getId()
            );
        } else if (original.getType() == TypeOperation.VIREMENT) {
            // Virement inverse
            compteBancaireService.transfer(
                    original.getNumeroCompteDestinataire(),
                    original.getCompteBancaire().getNumCompte(),
                    original.getMontant(),
                    "Annulation virement #" + original.getId()
            );
        }

        reverse.setCommentaire("Annulation de l'opération #" + original.getId());
        return operationRepository.save(reverse);
    }

    @Override
    public Operation correctOperation(Long operationId, BigDecimal newAmount, String raison) {
        Operation original = operationRepository.findById(operationId)
                .orElseThrow(() -> new ResourceNotFoundException("Operation", "id", operationId));

        // Annuler l'opération originale
        reverseOperation(operationId);

        // Créer une nouvelle opération avec le montant corrigé
        Operation corrected = new Operation(
                original.getCompteBancaire(),
                newAmount,
                original.getType(),
                "Correction: " + raison
        );

        return operationRepository.save(corrected);
    }

    @Override
    public byte[] exportOperationsToPdf(String numCompte, LocalDateTime start, LocalDateTime end) {
        // TODO: Implémenter l'export PDF avec une librairie comme iText ou Apache PDFBox
        throw new UnsupportedOperationException("Export PDF pas encore implémenté");
    }

    @Override
    public byte[] exportOperationsToExcel(String numCompte, LocalDateTime start, LocalDateTime end) {
        // TODO: Implémenter l'export Excel avec Apache POI
        throw new UnsupportedOperationException("Export Excel pas encore implémenté");
    }

    @Override
    public String generateOperationReceipt(Long operationId) {
        Operation operation = operationRepository.findById(operationId)
                .orElseThrow(() -> new ResourceNotFoundException("Operation", "id", operationId));

        StringBuilder receipt = new StringBuilder();
        receipt.append("=== REÇU D'OPÉRATION ===\n");
        receipt.append("Numéro d'opération: ").append(operation.getId()).append("\n");
        receipt.append("Date: ").append(operation.getDateOperation()).append("\n");
        receipt.append("Type: ").append(operation.getType()).append("\n");
        receipt.append("Montant: ").append(operation.getMontant()).append(" EUR\n");
        receipt.append("Compte: ").append(operation.getCompteBancaire().getNumCompte()).append("\n");

        if (operation.getNumeroCompteDestinataire() != null) {
            receipt.append("Compte destinataire: ").append(operation.getNumeroCompteDestinataire()).append("\n");
        }

        if (operation.getCommunication() != null) {
            receipt.append("Communication: ").append(operation.getCommunication()).append("\n");
        }

        receipt.append("========================\n");

        return receipt.toString();
    }
}