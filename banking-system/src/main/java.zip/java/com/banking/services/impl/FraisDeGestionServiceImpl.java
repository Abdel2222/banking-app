package com.banking.services.impl;

import com.banking.entities.Client;
import com.banking.entities.FraisDeGestion;
import com.banking.exceptions.BusinessException;
import com.banking.exceptions.ResourceNotFoundException;
import com.banking.repositories.FraisDeGestionRepository;
import com.banking.services.FraisDeGestionService;
import com.banking.services.ClientService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class FraisDeGestionServiceImpl implements FraisDeGestionService {

    private static final Logger logger = LoggerFactory.getLogger(FraisDeGestionServiceImpl.class);

    @Autowired
    private FraisDeGestionRepository fraisRepository;

    @Autowired
    private ClientService clientService;

    // ==================== CRUD DE BASE ====================

    @Override
    public FraisDeGestion creerFrais(FraisDeGestion frais) {
        logger.info("Création d'un nouveau frais de gestion pour le client ID: {}", frais.getClient().getId());

        // Validations métier
        validerFrais(frais);

        // Vérifier les doublons pour certains types de frais
        if (verifierDoublon(frais)) {
            throw new BusinessException("Un frais de ce type existe déjà pour cette période");
        }

        FraisDeGestion fraisCree = fraisRepository.save(frais);
        logger.info("Frais créé avec succès, ID: {}", fraisCree.getId());

        return fraisCree;
    }

    @Override
    @Transactional(readOnly = true)
    public FraisDeGestion obtenirFrais(Long id) {
        return fraisRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Frais non trouvé avec l'ID: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<FraisDeGestion> obtenirTousFrais() {
        return fraisRepository.findAll();
    }

    @Override
    public FraisDeGestion mettreAJourFrais(Long id, FraisDeGestion fraisModifie) {
        logger.info("Mise à jour du frais ID: {}", id);

        FraisDeGestion fraisExistant = obtenirFrais(id);

        // Mise à jour des champs modifiables
        if (fraisModifie.getMontant() != null) {
            fraisExistant.setMontant(fraisModifie.getMontant());
        }
        if (fraisModifie.getDescription() != null) {
            fraisExistant.setDescription(fraisModifie.getDescription());
        }
        if (fraisModifie.getDateFin() != null) {
            fraisExistant.setDateFin(fraisModifie.getDateFin());
        }
        if (fraisModifie.getPeriodicite() != null) {
            fraisExistant.setPeriodicite(fraisModifie.getPeriodicite());
        }

        // Validation après modification
        validerFrais(fraisExistant);

        FraisDeGestion fraisMisAJour = fraisRepository.save(fraisExistant);
        logger.info("Frais mis à jour avec succès");

        return fraisMisAJour;
    }

    @Override
    public void supprimerFrais(Long id) {
        logger.info("Suppression du frais ID: {}", id);

        FraisDeGestion frais = obtenirFrais(id);

        // Vérifier si le frais a été facturé
        if (frais.getMontantTotalFacture().compareTo(BigDecimal.ZERO) > 0) {
            throw new BusinessException("Impossible de supprimer un frais qui a déjà été facturé. Vous pouvez le désactiver.");
        }

        fraisRepository.delete(frais);
        logger.info("Frais supprimé avec succès");
    }

    // ==================== GESTION PAR CLIENT ====================

    @Override
    @Transactional(readOnly = true)
    public List<FraisDeGestion> obtenirFraisClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));
        return fraisRepository.findByClient(client);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FraisDeGestion> obtenirFraisActifsClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));
        // Utilisation des méthodes JPA de base en attendant
        return fraisRepository.findByClient(client).stream()
                .filter(FraisDeGestion::getEstActif)
                .collect(java.util.stream.Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<FraisDeGestion> obtenirFraisEnCoursClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));
        // Utilisation des méthodes JPA de base + filtrage Java
        return fraisRepository.findByClient(client).stream()
                .filter(FraisDeGestion::estEnCours)
                .collect(java.util.stream.Collectors.toList());
    }

    @Override
    public FraisDeGestion creerFraisClient(Long clientId, FraisDeGestion frais) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));
        frais.setClient(client);
        return creerFrais(frais);
    }

    // ==================== GESTION DE LA FACTURATION ====================

    @Override
    public List<FraisDeGestion> obtenirFraisAFacturer() {
        LocalDate aujourdhui = LocalDate.now();
        // Utilisation de findAll() + filtrage Java en attendant la méthode custom
        return fraisRepository.findAll().stream()
                .filter(f -> f.doitEtreFacture())
                .collect(java.util.stream.Collectors.toList());
    }

    @Override
    public void facturerFrais(Long fraisId) {
        logger.info("Facturation du frais ID: {}", fraisId);

        FraisDeGestion frais = obtenirFrais(fraisId);

        if (!frais.doitEtreFacture()) {
            throw new BusinessException("Ce frais ne peut pas être facturé maintenant");
        }

        // Facturer via la méthode métier de l'entité
        frais.facturer();
        fraisRepository.save(frais);

        // Créer une opération de débit pour le client
        creerOperationFacturation(frais);

        logger.info("Frais facturé avec succès. Montant: {}", frais.getMontant());
    }

    @Override
    public void facturerFraisClient(Long clientId) {
        logger.info("Facturation de tous les frais du client ID: {}", clientId);

        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));

        // Filtrage des frais à facturer pour ce client
        List<FraisDeGestion> fraisAFacturer = fraisRepository.findByClient(client).stream()
                .filter(FraisDeGestion::doitEtreFacture)
                .collect(java.util.stream.Collectors.toList());

        BigDecimal montantTotal = BigDecimal.ZERO;
        int nombreFacturations = 0;

        for (FraisDeGestion frais : fraisAFacturer) {
            try {
                facturerFrais(frais.getId());
                montantTotal = montantTotal.add(frais.getMontant());
                nombreFacturations++;
            } catch (Exception e) {
                logger.error("Erreur lors de la facturation du frais ID: {}", frais.getId(), e);
            }
        }

        logger.info("Facturation terminée pour le client {}. {} frais facturés pour un montant total de {}",
                clientId, nombreFacturations, montantTotal);
    }

    @Override
    @Scheduled(cron = "0 0 6 * * *") // Tous les jours à 6h du matin
    public void facturationAutomatique() {
        logger.info("Début de la facturation automatique");

        List<FraisDeGestion> fraisAFacturer = obtenirFraisAFacturer();

        BigDecimal montantTotal = BigDecimal.ZERO;
        int nombreFacturations = 0;
        int nombreEchecs = 0;

        for (FraisDeGestion frais : fraisAFacturer) {
            try {
                facturerFrais(frais.getId());
                montantTotal = montantTotal.add(frais.getMontant());
                nombreFacturations++;
            } catch (Exception e) {
                logger.error("Erreur lors de la facturation automatique du frais ID: {}", frais.getId(), e);
                nombreEchecs++;
            }
        }

        logger.info("Facturation automatique terminée. {} succès, {} échecs, montant total: {}",
                nombreFacturations, nombreEchecs, montantTotal);
    }

    // ==================== GESTION DU CYCLE DE VIE ====================

    @Override
    public void activerFrais(Long fraisId) {
        logger.info("Activation du frais ID: {}", fraisId);

        FraisDeGestion frais = obtenirFrais(fraisId);
        frais.reactiver(); // Utilise la logique métier de l'entité
        fraisRepository.save(frais);

        logger.info("Frais activé avec succès");
    }

    @Override
    public void desactiverFrais(Long fraisId) {
        logger.info("Désactivation du frais ID: {}", fraisId);

        FraisDeGestion frais = obtenirFrais(fraisId);
        frais.desactiver();
        fraisRepository.save(frais);

        logger.info("Frais désactivé avec succès");
    }

    @Override
    @Scheduled(cron = "0 30 6 * * *") // Tous les jours à 6h30
    public void desactiverFraisExpires() {
        logger.info("Désactivation automatique des frais expirés");

        // Version simplifiée avec filtrage Java
        List<FraisDeGestion> fraisExpires = fraisRepository.findAll().stream()
                .filter(f -> f.getEstActif() && f.estEchu())
                .collect(java.util.stream.Collectors.toList());

        int nombreDesactives = 0;
        for (FraisDeGestion frais : fraisExpires) {
            frais.desactiver();
            fraisRepository.save(frais);
            nombreDesactives++;
        }

        logger.info("{} frais expirés ont été désactivés automatiquement", nombreDesactives);
    }

    // ==================== STATISTIQUES ====================

    @Override
    @Transactional(readOnly = true)
    public BigDecimal calculerMontantTotalActifClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));

        // Calcul avec filtrage Java
        return fraisRepository.findByClient(client).stream()
                .filter(FraisDeGestion::getEstActif)
                .filter(FraisDeGestion::estEnCours)
                .map(FraisDeGestion::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    @Transactional(readOnly = true)
    public BigDecimal calculerMontantTotalFactureClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));

        // Calcul avec filtrage Java
        return fraisRepository.findByClient(client).stream()
                .map(FraisDeGestion::getMontantTotalFacture)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Override
    @Transactional(readOnly = true)
    public Long compterFraisActifsClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));

        // Comptage avec filtrage Java
        return fraisRepository.findByClient(client).stream()
                .filter(FraisDeGestion::getEstActif)
                .count();
    }

    // ==================== RECHERCHES AVANCÉES ====================

    @Override
    @Transactional(readOnly = true)
    public List<FraisDeGestion> rechercherFrais(FraisDeGestion.TypeFrais typeFrais,
                                                FraisDeGestion.Periodicite periodicite,
                                                Boolean estActif,
                                                LocalDate dateDebut,
                                                LocalDate dateFin) {
        // Implémentation d'une recherche multicritères
        // Pour simplifier, on utilise les méthodes du repository
        List<FraisDeGestion> resultats = fraisRepository.findAll();

        return resultats.stream()
                .filter(f -> typeFrais == null || f.getTypeFrais().equals(typeFrais))
                .filter(f -> periodicite == null || f.getPeriodicite().equals(periodicite))
                .filter(f -> estActif == null || f.getEstActif().equals(estActif))
                .filter(f -> dateDebut == null || !f.getDateDebut().isBefore(dateDebut))
                .filter(f -> dateFin == null || !f.getDateFin().isAfter(dateFin))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<FraisDeGestion> obtenirHistoriqueFacturationClient(Long clientId) {
        Client client = clientService.findById(clientId)
                .orElseThrow(() -> new ResourceNotFoundException("Client non trouvé avec l'ID: " + clientId));

        // Filtrage et tri avec Java
        return fraisRepository.findByClient(client).stream()
                .filter(f -> f.getDerniereFacturation() != null)
                .sorted((f1, f2) -> f2.getDerniereFacturation().compareTo(f1.getDerniereFacturation()))
                .collect(java.util.stream.Collectors.toList());
    }

    // ==================== MÉTHODES PRIVÉES ====================

    private void validerFrais(FraisDeGestion frais) {
        if (frais.getDateDebut().isAfter(frais.getDateFin())) {
            throw new BusinessException("La date de début ne peut pas être postérieure à la date de fin");
        }

        if (frais.getMontant().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("Le montant doit être positif");
        }

        if (frais.getClient() == null) {
            throw new BusinessException("Le client est obligatoire");
        }
    }

    private boolean verifierDoublon(FraisDeGestion frais) {
        // Vérifier les doublons pour les frais de tenue de compte et carte bancaire
        if (frais.getTypeFrais() == FraisDeGestion.TypeFrais.TENUE_COMPTE ||
                frais.getTypeFrais() == FraisDeGestion.TypeFrais.CARTE_BANCAIRE) {

            // Utilisation du filtrage Java au lieu de la méthode repository
            List<FraisDeGestion> fraisExistants = fraisRepository.findByClientAndTypeFrais(
                            frais.getClient(), frais.getTypeFrais()).stream()
                    .filter(FraisDeGestion::getEstActif)
                    .collect(java.util.stream.Collectors.toList());

            return fraisExistants.stream()
                    .anyMatch(f -> periodesSeRecoupent(f, frais));
        }

        return false;
    }

    private boolean periodesSeRecoupent(FraisDeGestion frais1, FraisDeGestion frais2) {
        return !frais1.getDateFin().isBefore(frais2.getDateDebut()) &&
                !frais2.getDateFin().isBefore(frais1.getDateDebut());
    }

    private void creerOperationFacturation(FraisDeGestion frais) {
        try {
            // Supposons que le client ait au moins un compte
            // Dans un vrai système, vous pourriez avoir une logique plus sophistiquée
            if (!frais.getClient().getComptes().isEmpty()) {
                // Pour l'instant, on va juste logger l'opération
                // Vous devrez adapter cette partie selon votre structure Operation existante
                logger.info("Facturation de {} € pour le frais: {} du client: {}",
                        frais.getMontant(),
                        frais.getDescription(),
                        frais.getClient().getEmail());

                // Si vous avez un OperationService, vous pourriez faire quelque chose comme :
                // operationService.debiter(frais.getClient().getComptes().get(0).getId(),
                //                         frais.getMontant(),
                //                         "Facturation: " + frais.getDescription());
            }
        } catch (Exception e) {
            logger.warn("Impossible de créer l'opération de facturation pour le frais ID: {}",
                    frais.getId(), e);
        }
    }
}