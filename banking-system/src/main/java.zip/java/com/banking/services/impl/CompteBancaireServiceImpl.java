package com.banking.services.impl;

import com.banking.entities.*;
import com.banking.entity.enums.AccountStatus;
import com.banking.entity.enums.TypeOperation;
import com.banking.repositories.*;
import com.banking.services.CompteBancaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional
public class CompteBancaireServiceImpl implements CompteBancaireService {

    @Autowired
    private CompteBancaireRepository compteBancaireRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private OperationRepository operationRepository;

    @Autowired
    private CarteBancaireRepository carteBancaireRepository;

    @Autowired
    private CompteEpargneRepository compteEpargneRepository;

    @Override
    public CompteBancaire createAccount(Long clientId) {
        Client client = clientRepository.findById(clientId)
                .orElseThrow(() -> new RuntimeException("Client non trouvé"));

        String numCompte = generateAccountNumber();
        CompteBancaire compte = new CompteBancaire(numCompte, client);
        return compteBancaireRepository.save(compte);
    }

    @Override
    public Optional<CompteBancaire> findById(Long id) {
        return compteBancaireRepository.findById(id);
    }

    @Override
    public Optional<CompteBancaire> findByNumCompte(String numCompte) {
        return compteBancaireRepository.findByNumCompte(numCompte);
    }

    @Override
    public List<CompteBancaire> findAll() {
        return compteBancaireRepository.findAll();
    }

    @Override
    public CompteBancaire updateAccount(Long id, CompteBancaire accountDetails) {
        CompteBancaire compte = compteBancaireRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        // Mise à jour des champs autorisés
        compte.setStatus(accountDetails.getStatus());

        return compteBancaireRepository.save(compte);
    }

    @Override
    public void deleteAccount(Long id) {
        CompteBancaire compte = compteBancaireRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        if (compte.getBalance().compareTo(BigDecimal.ZERO) != 0) {
            throw new IllegalStateException("Impossible de supprimer un compte avec un solde non nul");
        }

        compteBancaireRepository.delete(compte);
    }

    @Override
    public Operation deposit(String numCompte, BigDecimal montant, String description) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        compte.crediter(montant);
        compteBancaireRepository.save(compte);

        Operation operation = new Operation(compte, montant, TypeOperation.DEPOT, description);
        return operationRepository.save(operation);
    }

    @Override
    public Operation withdraw(String numCompte, BigDecimal montant, String description) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        compte.debiter(montant);
        compteBancaireRepository.save(compte);

        Operation operation = new Operation(compte, montant, TypeOperation.RETRAIT, description);
        return operationRepository.save(operation);
    }

    @Override
    @Transactional
    public Operation transfer(String numCompteSource, String numCompteDestinataire,
                              BigDecimal montant, String communication) {
        CompteBancaire compteSource = compteBancaireRepository.findByNumCompte(numCompteSource)
                .orElseThrow(() -> new RuntimeException("Compte source non trouvé"));

        CompteBancaire compteDestinataire = compteBancaireRepository.findByNumCompte(numCompteDestinataire)
                .orElseThrow(() -> new RuntimeException("Compte destinataire non trouvé"));

        // Débiter le compte source
        compteSource.debiter(montant);
        compteBancaireRepository.save(compteSource);

        // Créditer le compte destinataire
        compteDestinataire.crediter(montant);
        compteBancaireRepository.save(compteDestinataire);

        // Créer l'opération de virement
        Operation operation = new Operation(compteSource, montant, TypeOperation.VIREMENT);
        operation.setNumeroCompteDestinataire(numCompteDestinataire);
        operation.setCommunication(communication);
        operation.setNomTitulaireDestinataire(
                compteDestinataire.getClient().getNomComplet()
        );

        return operationRepository.save(operation);
    }

    @Override
    public CompteBancaire activateAccount(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        compte.activate();
        return compteBancaireRepository.save(compte);
    }

    @Override
    public CompteBancaire suspendAccount(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        compte.suspend();
        return compteBancaireRepository.save(compte);
    }

    @Override
    public CompteBancaire closeAccount(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        compte.close();
        return compteBancaireRepository.save(compte);
    }

    @Override
    public CarteBancaire issueCard(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        // Vérifier s'il n'a pas déjà une carte
        if (carteBancaireRepository.findByCompteBancaire(compte).isPresent()) {
            throw new IllegalStateException("Ce compte possède déjà une carte");
        }

        String numeroCarte = generateCardNumber();
        String cvv = generateCVV();
        LocalDate expiration = LocalDate.now().plusYears(3);

        CarteBancaire carte = new CarteBancaire(numeroCarte, expiration, cvv, compte);
        return carteBancaireRepository.save(carte);
    }

    @Override
    public CarteBancaire blockCard(String numCompte, String raison) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CarteBancaire carte = carteBancaireRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Aucune carte associée à ce compte"));

        carte.bloquer();
        carteBancaireRepository.save(carte);

        // Créer une opération de blocage
        Operation operation = new Operation(compte, BigDecimal.ZERO, TypeOperation.BLOCAGE_CARTE, raison);
        operationRepository.save(operation);

        return carte;
    }

    @Override
    public CarteBancaire unblockCard(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CarteBancaire carte = carteBancaireRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Aucune carte associée à ce compte"));

        carte.debloquer();
        return carteBancaireRepository.save(carte);
    }

    @Override
    public Optional<CarteBancaire> getCard(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        return carteBancaireRepository.findByCompteBancaire(compte);
    }

    @Override
    public CompteEpargne convertToSavingsAccount(String numCompte, BigDecimal tauxInteret) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        // Vérifier s'il n'est pas déjà un compte épargne
        if (compteEpargneRepository.findByCompteBancaire(compte).isPresent()) {
            throw new IllegalStateException("Ce compte est déjà un compte épargne");
        }

        CompteEpargne epargne = new CompteEpargne(
                new BigDecimal("50.00"), // Montant minimum
                tauxInteret,
                compte
        );

        return compteEpargneRepository.save(epargne);
    }

    @Override
    public CompteEpargne updateSavingsRate(String numCompte, BigDecimal nouveauTaux) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CompteEpargne epargne = compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Ce n'est pas un compte épargne"));

        epargne.setTauxInteret(nouveauTaux);
        return compteEpargneRepository.save(epargne);
    }

    @Override
    public void capitalizeInterests(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CompteEpargne epargne = compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Ce n'est pas un compte épargne"));

        if (epargne.doitCapitaliser()) {
            epargne.capitaliserInterets();
            compteEpargneRepository.save(epargne);
            compteBancaireRepository.save(compte);
        }
    }

    @Override
    public BigDecimal calculateInterests(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CompteEpargne epargne = compteEpargneRepository.findByCompteBancaire(compte)
                .orElseThrow(() -> new RuntimeException("Ce n'est pas un compte épargne"));

        return epargne.calculerInteretsAnnuels();
    }

    @Override
    public BigDecimal getBalance(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        return compte.getBalance();
    }

    @Override
    public List<Operation> getAccountHistory(String numCompte, LocalDateTime debut, LocalDateTime fin) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        return operationRepository.findByCompteAndDateBetween(compte, debut, fin);
    }

    @Override
    public List<Operation> getLastOperations(String numCompte, int nombre) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        return operationRepository.findLastOperations(compte, PageRequest.of(0, nombre));
    }

    @Override
    public Map<String, BigDecimal> getAccountStatistics(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        Map<String, BigDecimal> stats = new HashMap<>();
        stats.put("solde", compte.getBalance());
        stats.put("totalDepots", operationRepository.sumDepositsByAccount(compte));
        stats.put("totalRetraits", operationRepository.sumWithdrawalsByAccount(compte));

        // Calculer le solde moyen sur les 30 derniers jours
        LocalDateTime thirtyDaysAgo = LocalDateTime.now().minusDays(30);
        List<Operation> recentOps = operationRepository.findByCompteAndDateBetween(
                compte, thirtyDaysAgo, LocalDateTime.now()
        );

        BigDecimal totalMouvements = recentOps.stream()
                .map(Operation::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        stats.put("mouvementsMensuels", totalMouvements);

        return stats;
    }

    @Override
    public List<CompteBancaire> findByStatus(AccountStatus status) {
        return compteBancaireRepository.findByStatus(status);
    }

    @Override
    public List<CompteBancaire> findAccountsWithLowBalance(BigDecimal threshold) {
        return compteBancaireRepository.findAll().stream()
                .filter(compte -> compte.getBalance().compareTo(threshold) < 0)
                .toList();
    }

    @Override
    public List<CompteBancaire> findInactiveAccounts(int daysSinceLastActivity) {
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(daysSinceLastActivity);
        return compteBancaireRepository.findInactiveAccountsOlderThan(cutoffDate);
    }

    @Override
    public List<CompteBancaire> findAccountsNeedingAttention() {
        List<CompteBancaire> accounts = new ArrayList<>();

        // Comptes avec solde très bas
        accounts.addAll(findAccountsWithLowBalance(new BigDecimal("50")));

        // Comptes inactifs depuis plus de 90 jours
        accounts.addAll(findInactiveAccounts(90));

        // Comptes avec cartes expirées
        LocalDate now = LocalDate.now();
        List<CarteBancaire> expiredCards = carteBancaireRepository.findExpiredCards(now);
        for (CarteBancaire carte : expiredCards) {
            if (!accounts.contains(carte.getCompteBancaire())) {
                accounts.add(carte.getCompteBancaire());
            }
        }

        return accounts;
    }

    @Override
    public boolean accountExists(String numCompte) {
        return compteBancaireRepository.existsByNumCompte(numCompte);
    }

    @Override
    public boolean canPerformOperation(String numCompte, BigDecimal montant) {
        Optional<CompteBancaire> compte = compteBancaireRepository.findByNumCompte(numCompte);
        if (compte.isEmpty()) {
            return false;
        }

        CompteBancaire cb = compte.get();
        return cb.isActive() && cb.getBalance().compareTo(montant) >= 0;
    }

    @Override
    public boolean hasCard(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        return carteBancaireRepository.findByCompteBancaire(compte).isPresent();
    }

    @Override
    public boolean isSavingsAccount(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        return compteEpargneRepository.findByCompteBancaire(compte).isPresent();
    }

    @Override
    public void setWithdrawalLimit(String numCompte, BigDecimal dailyLimit) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CarteBancaire carte = carteBancaireRepository.findByCompteBancaire(compte)
                .orElse(null);

        if (carte != null) {
            carte.setPlafondJournalier(dailyLimit.doubleValue());
            carteBancaireRepository.save(carte);
        }
    }

    @Override
    public void setTransferLimit(String numCompte, BigDecimal monthlyLimit) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CarteBancaire carte = carteBancaireRepository.findByCompteBancaire(compte)
                .orElse(null);

        if (carte != null) {
            carte.setPlafondMensuel(monthlyLimit.doubleValue());
            carteBancaireRepository.save(carte);
        }
    }

    @Override
    public BigDecimal getRemainingDailyLimit(String numCompte) {
        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        CarteBancaire carte = carteBancaireRepository.findByCompteBancaire(compte)
                .orElse(null);

        if (carte == null) {
            return BigDecimal.ZERO;
        }

        // Calculer le total des retraits du jour
        LocalDateTime startOfDay = LocalDate.now().atStartOfDay();
        List<Operation> todayWithdrawals = operationRepository.findByCompteAndDateBetween(
                        compte, startOfDay, LocalDateTime.now()
                ).stream()
                .filter(op -> op.getType() == TypeOperation.RETRAIT)
                .toList();

        BigDecimal totalToday = todayWithdrawals.stream()
                .map(Operation::getMontant)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal limit = BigDecimal.valueOf(carte.getPlafondJournalier());
        return limit.subtract(totalToday);
    }

    @Override
    public void sendLowBalanceAlert(String numCompte) {
        // TODO: Implémenter l'envoi d'alertes (email, SMS, etc.)
        System.out.println("Alerte solde bas envoyée pour le compte " + numCompte);
    }

    @Override
    public void sendStatementNotification(String numCompte) {
        // TODO: Implémenter l'envoi de relevés
        System.out.println("Relevé envoyé pour le compte " + numCompte);
    }

    @Override
    public List<String> getPendingNotifications(String numCompte) {
        List<String> notifications = new ArrayList<>();

        CompteBancaire compte = compteBancaireRepository.findByNumCompte(numCompte)
                .orElseThrow(() -> new RuntimeException("Compte non trouvé"));

        // Vérifier le solde bas
        if (compte.getBalance().compareTo(new BigDecimal("100")) < 0) {
            notifications.add("Votre solde est bas : " + compte.getBalance() + "€");
        }

        // Vérifier la carte expirée
        Optional<CarteBancaire> carte = carteBancaireRepository.findByCompteBancaire(compte);
        if (carte.isPresent() && carte.get().estExpiree()) {
            notifications.add("Votre carte bancaire a expiré");
        }

        // Vérifier les frais impayés
        if (compte.getClient().aDesFraisImpayés()) {
            notifications.add("Vous avez des frais impayés");
        }

        return notifications;
    }

    private String generateAccountNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    private String generateCardNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    private String generateCVV() {
        Random random = new Random();
        return String.format("%03d", random.nextInt(1000));
    }
}