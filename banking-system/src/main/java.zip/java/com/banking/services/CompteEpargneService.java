package com.banking.services;

import com.banking.entities.CompteEpargne;

import java.math.BigDecimal;

public interface CompteEpargneService {
    CompteEpargne findByCompteId(Long compteId);
    BigDecimal calculerInterets(String numCompte);
    void capitaliserInterets(String numCompte);
    boolean doitCapitaliser(String numCompte);
}

