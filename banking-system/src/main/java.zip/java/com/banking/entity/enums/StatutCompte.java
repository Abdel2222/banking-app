package com.banking.entity.enums;

public enum StatutCompte {
    CREE,
    ACTIVE,
    SUSPENDU
}
