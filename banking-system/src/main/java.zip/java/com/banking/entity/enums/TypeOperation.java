package com.banking.entity.enums;

public enum TypeOperation {
    DEPOT,
    RETRAIT,
    VIREMENT,
    BLOCAGE_CARTE
}